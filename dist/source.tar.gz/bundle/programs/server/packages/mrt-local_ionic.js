(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Platform, IonActionSheet, IonBackdrop, IonHeaderBar, IonKeyboard, IonLoading, IonModal, IonNavigation, IonPopover, IonPopup, IonSideMenu;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mrt-local:ionic'] = {
  Platform: Platform,
  IonActionSheet: IonActionSheet,
  IonBackdrop: IonBackdrop,
  IonHeaderBar: IonHeaderBar,
  IonKeyboard: IonKeyboard,
  IonLoading: IonLoading,
  IonModal: IonModal,
  IonNavigation: IonNavigation,
  IonPopover: IonPopover,
  IonPopup: IonPopup,
  IonSideMenu: IonSideMenu
};

})();

//# sourceMappingURL=mrt-local_ionic.js.map
