(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['zeroasterisk:cordova-geolocation-background'] = {};

})();

//# sourceMappingURL=zeroasterisk_cordova-geolocation-background.js.map
