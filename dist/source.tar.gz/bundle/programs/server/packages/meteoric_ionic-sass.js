(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['meteoric:ionic-sass'] = {};

})();

//# sourceMappingURL=meteoric_ionic-sass.js.map
